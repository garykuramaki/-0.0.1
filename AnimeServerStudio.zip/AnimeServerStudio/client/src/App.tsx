import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import CreateServer from "@/pages/create-server";
import AIServer from "@/pages/ai-server";
import CompletedAnime from "@/pages/completed-anime";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import MobileMenu from "@/components/layout/mobile-menu";
import { useState } from "react";

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <TooltipProvider>
      <Toaster />
      <Navbar />
      <div className="flex min-h-[calc(100vh-64px)]" dir="rtl">
        <Sidebar isOpen={true} />
        <MobileMenu isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/create-server" component={CreateServer} />
            <Route path="/ai-server" component={AIServer} />
            <Route path="/completed-anime" component={CompletedAnime} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>

      {/* Mobile sidebar toggle */}
      <div className="fixed bottom-4 right-4 md:hidden z-50">
        <button 
          onClick={toggleSidebar}
          className="bg-primary-600 text-white p-3 rounded-full shadow-lg"
        >
          <span className="material-icons">menu</span>
        </button>
      </div>
    </TooltipProvider>
  );
}

export default App;
