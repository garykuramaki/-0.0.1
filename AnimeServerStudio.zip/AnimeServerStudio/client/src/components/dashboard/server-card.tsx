import React from 'react';
import { useState } from 'react';
import { ServerStatusBadge } from '@/components/ui/server-status-badge';
import { cn } from '@/lib/utils';
import { type Server, formatTime } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface ServerCardProps {
  server: Server;
}

export function ServerCard({ server }: ServerCardProps) {
  const [showApiKey, setShowApiKey] = useState(false);
  const { toast } = useToast();
  
  const getStatusType = (status: string): 'active' | 'warning' | 'error' | 'processing' => {
    switch (status) {
      case 'active': return 'active';
      case 'pending': return 'warning';
      case 'stopped': return 'error';
      case 'processing': return 'processing';
      default: return 'active';
    }
  };
  
  const getServerIcon = (type: string): string => {
    switch (type) {
      case 'web': return 'storage';
      case 'database': return 'dns';
      case 'ai': return 'memory';
      default: return 'storage';
    }
  };
  
  const getServerTypeColor = (type: string): string => {
    switch (type) {
      case 'web': return 'primary';
      case 'database': return 'accent';
      case 'ai': return 'secondary';
      default: return 'primary';
    }
  };
  
  const statusMessages: Record<string, string> = {
    active: `نشط منذ ${formatTime(server.uptime)}`,
    pending: 'قيد الإعداد',
    stopped: 'متوقف',
    processing: 'تحت الحمل العالي - في حالة معالجة'
  };
  
  const color = getServerTypeColor(server.type);
  const icon = getServerIcon(server.type);
  const statusType = getStatusType(server.status);
  
  const copyApiKey = () => {
    if (server.apiKey) {
      navigator.clipboard.writeText(server.apiKey)
        .then(() => {
          toast({
            title: "تم النسخ",
            description: "تم نسخ مفتاح API إلى الحافظة",
          });
        })
        .catch(err => {
          toast({
            title: "فشل النسخ",
            description: "تعذر نسخ مفتاح API",
            variant: "destructive",
          });
        });
    }
  };
  
  return (
    <div className="bg-white rounded-xl shadow-md p-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div className="flex items-center mb-4 md:mb-0">
          <div className={`w-10 h-10 rounded-lg bg-${color}-100 flex items-center justify-center mr-3`}>
            <span className={`material-icons text-${color}-600`}>{icon}</span>
          </div>
          <div>
            <h3 className="font-medium">{server.name}</h3>
            <div className="text-sm text-dark-500 flex items-center">
              <ServerStatusBadge status={statusType} text={statusMessages[server.status]} />
              {server.persistentMode && (
                <span className="mr-2 text-xs bg-secondary-500 bg-opacity-10 text-secondary-500 px-2 py-1 rounded-full">
                  <span className="material-icons text-xs mr-1 align-text-bottom">all_inclusive</span>
                  وضع الاستمرارية مفعل
                </span>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap md:flex-nowrap gap-2">
          {server.resources && (
            <>
              <div className="px-3 py-1 bg-light-100 rounded-lg text-sm flex items-center">
                <span className="material-icons text-dark-500 text-xs mr-1">memory</span>
                {server.resources.cpu} vCPU
              </div>
              <div className="px-3 py-1 bg-light-100 rounded-lg text-sm flex items-center">
                <span className="material-icons text-dark-500 text-xs mr-1">sd_card</span>
                {server.resources.ram} GB RAM
              </div>
              <div className="px-3 py-1 bg-light-100 rounded-lg text-sm flex items-center">
                <span className="material-icons text-dark-500 text-xs mr-1">storage</span>
                {server.resources.storage} GB
              </div>
              {server.resources.gpu && (
                <div className="px-3 py-1 bg-accent-100 text-accent-700 rounded-lg text-sm flex items-center">
                  <span className="material-icons text-accent-700 text-xs mr-1">memory</span>
                  {server.resources.gpu}
                </div>
              )}
            </>
          )}
          <div className="relative">
            <button className="px-3 py-1 bg-light-100 hover:bg-light-200 rounded-lg text-sm">
              <span className="material-icons text-sm">more_vert</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* مفتاح API */}
      {server.apiKey && (
        <div className="mt-4 p-3 bg-light-100 rounded-lg">
          <div className="flex justify-between items-center">
            <div className="font-medium text-sm">مفتاح API الخاص بالسيرفر</div>
            <div className="flex gap-2">
              <button 
                onClick={() => setShowApiKey(!showApiKey)} 
                className="text-xs bg-primary-50 text-primary-600 px-2 py-1 rounded"
              >
                <span className="material-icons text-xs align-text-bottom">{showApiKey ? 'visibility_off' : 'visibility'}</span>
                {showApiKey ? 'إخفاء' : 'إظهار'}
              </button>
              <button 
                onClick={copyApiKey} 
                className="text-xs bg-primary-50 text-primary-600 px-2 py-1 rounded"
              >
                <span className="material-icons text-xs align-text-bottom">content_copy</span>
                نسخ
              </button>
            </div>
          </div>
          {showApiKey ? (
            <div className="mt-2 p-2 bg-white border border-light-200 rounded font-mono text-xs overflow-x-auto select-all">
              {server.apiKey}
            </div>
          ) : (
            <div className="mt-2 p-2 bg-white border border-light-200 rounded font-mono text-xs">
              ••••••••••••••••••••••••••••••••
            </div>
          )}
          <div className="text-xs text-dark-500 mt-1">
            استخدم هذا المفتاح للوصول إلى واجهة برمجة التطبيقات (API) الخاصة بهذا السيرفر
          </div>
        </div>
      )}
      
      {/* Progress bar for AI server processing */}
      {server.type === 'ai' && server.status === 'processing' && server.usage && server.usage.gpu && (
        <div className="mt-4">
          <div className="flex justify-between text-sm mb-1">
            <span>معالجة حلقة أنمي: "المغامرة الغامضة" - الجزء 3</span>
            <span className="text-dark-500">{server.usage.gpu}% مكتمل</span>
          </div>
          <div className="w-full bg-light-200 rounded-full h-2">
            <div 
              className="bg-secondary-500 h-2 rounded-full animate-pulse-slow" 
              style={{ width: `${server.usage.gpu}%` }}
            ></div>
          </div>
          <div className="text-xs text-dark-500 mt-1">
            الوقت المتبقي: ~1 ساعة و 10 دقائق
          </div>
        </div>
      )}
    </div>
  );
}
