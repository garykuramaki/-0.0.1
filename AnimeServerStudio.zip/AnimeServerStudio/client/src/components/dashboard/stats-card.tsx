import React from 'react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  statusText?: string;
  statusColor?: string;
}

export function StatsCard({ title, value, icon, statusText, statusColor }: StatsCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h3 className="text-lg font-medium mb-4">{title}</h3>
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <span className={`material-icons text-${statusColor || 'primary'}-500 mr-2`}>{icon}</span>
          <span className="text-3xl font-bold">{value}</span>
        </div>
        {statusText && (
          <span className={`text-${statusColor || 'secondary'}-500 bg-${statusColor || 'secondary'}-500 bg-opacity-10 px-3 py-1 rounded-full text-sm`}>
            {statusText}
          </span>
        )}
      </div>
    </div>
  );
}
