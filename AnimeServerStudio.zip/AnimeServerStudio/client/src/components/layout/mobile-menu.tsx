import React, { useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const [location] = useLocation();
  
  useEffect(() => {
    // Close the menu when location changes
    onClose();
  }, [location, onClose]);
  
  // Close the menu when clicking outside
  useEffect(() => {
    if (!isOpen) return;
    
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (target.closest('[data-mobile-menu]')) return;
      onClose();
    };
    
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [isOpen, onClose]);
  
  if (!isOpen) return null;
  
  const menuItems = [
    { path: "/", icon: "dashboard", label: "لوحة التحكم" },
    { path: "/servers", icon: "storage", label: "السيرفرات" },
    { path: "/ai-server", icon: "memory", label: "سيرفرات الذكاء الاصطناعي" },
    { path: "/create-server", icon: "add_circle", label: "إنشاء سيرفر" },
    { path: "/completed-anime", icon: "movie", label: "حلقات الأنمي" },
    { path: "/monitoring", icon: "monitoring", label: "مراقبة الموارد" },
    { path: "/settings", icon: "settings", label: "الإعدادات" }
  ];
  
  return (
    <div 
      data-mobile-menu
      className="fixed inset-0 z-50 bg-black bg-opacity-50"
    >
      <div className="w-64 h-full bg-white shadow-xl">
        <div className="p-4 flex justify-between items-center border-b">
          <div className="text-xl font-bold text-primary-600">سيرفرلي</div>
          <button onClick={onClose} className="p-2">
            <span className="material-icons">close</span>
          </button>
        </div>
        <nav className="p-4">
          <ul className="space-y-1">
            {menuItems.map((item) => (
              <li key={item.path}>
                <Link
                  href={item.path}
                  className={cn(
                    "flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-lg",
                    location === item.path 
                      ? "bg-primary-50 text-primary-700" 
                      : "hover:bg-light-100 text-dark-600"
                  )}
                >
                  <span className="material-icons">{item.icon}</span>
                  <span>{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
}
