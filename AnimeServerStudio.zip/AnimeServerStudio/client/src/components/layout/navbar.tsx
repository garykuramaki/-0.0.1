import React from 'react';
import { useLocation } from 'wouter';

export default function Navbar() {
  const [, navigate] = useLocation();
  
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-4 space-x-reverse">
          <div 
            className="text-2xl font-bold text-primary-600 cursor-pointer" 
            onClick={() => navigate('/')}
          >
            سيرفرلي
          </div>
          <div className="text-sm text-dark-500">منصة إنشاء وإدارة السيرفرات</div>
        </div>
        
        <div className="flex items-center space-x-4 space-x-reverse">
          <button className="p-2 rounded-full hover:bg-light-100">
            <span className="material-icons">notifications</span>
          </button>
          <button className="p-2 rounded-full hover:bg-light-100">
            <span className="material-icons">help</span>
          </button>
          
          <div className="relative">
            <button className="flex items-center space-x-2 space-x-reverse bg-light-100 rounded-full px-3 py-1">
              <span className="material-icons text-dark-500">account_circle</span>
              <span>أحمد</span>
              <span className="material-icons text-dark-500">arrow_drop_down</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
