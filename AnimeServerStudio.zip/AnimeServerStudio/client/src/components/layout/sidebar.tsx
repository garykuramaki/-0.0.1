import React from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';

interface SidebarProps {
  isOpen: boolean;
}

export default function Sidebar({ isOpen }: SidebarProps) {
  const [location] = useLocation();
  
  const menuItems = [
    { path: "/", icon: "dashboard", label: "لوحة التحكم" },
    { path: "/servers", icon: "storage", label: "السيرفرات" },
    { path: "/ai-server", icon: "memory", label: "سيرفرات الذكاء الاصطناعي" },
    { path: "/create-server", icon: "add_circle", label: "إنشاء سيرفر" },
    { path: "/completed-anime", icon: "movie", label: "حلقات الأنمي" },
    { path: "/monitoring", icon: "monitoring", label: "مراقبة الموارد" },
    { path: "/settings", icon: "settings", label: "الإعدادات" }
  ];
  
  if (!isOpen) return null;
  
  return (
    <aside className="w-64 bg-white shadow-md hidden md:block">
      <nav className="p-4">
        <ul className="space-y-1">
          {menuItems.map((item) => (
            <li key={item.path}>
              <Link 
                href={item.path}
                className={cn(
                  "flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-lg",
                  location === item.path 
                    ? "bg-primary-50 text-primary-700" 
                    : "hover:bg-light-100 text-dark-600"
                )}
              >
                <span className="material-icons">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}
