import React from 'react';
import { cn } from '@/lib/utils';

interface ResourceMeterProps {
  label: string;
  value: string;
  percentage: number;
  colorClass?: string;
  animate?: boolean;
}

export function ResourceMeter({ 
  label, 
  value, 
  percentage, 
  colorClass = "bg-primary-500", 
  animate = false 
}: ResourceMeterProps) {
  return (
    <div className="bg-light-100 rounded-lg p-3">
      <div className="text-dark-500 text-sm mb-1">{label}</div>
      <div className="font-medium">{value}</div>
      <div className="w-full bg-light-200 rounded-full h-2 mt-2">
        <div 
          className={cn(
            "h-2 rounded-full", 
            colorClass, 
            { "animate-pulse-slow": animate }
          )} 
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
}
