import React from 'react';
import { cn } from '@/lib/utils';

type StatusType = 'active' | 'warning' | 'error' | 'processing';

interface ServerStatusBadgeProps {
  status: StatusType;
  text: string;
  className?: string;
}

export function ServerStatusBadge({ status, text, className }: ServerStatusBadgeProps) {
  const statusStyles = {
    active: "bg-state-success bg-opacity-10 text-state-success",
    warning: "bg-state-warning bg-opacity-10 text-state-warning",
    error: "bg-state-error bg-opacity-10 text-state-error",
    processing: "bg-accent-500 bg-opacity-10 text-accent-600",
  };

  return (
    <span className={cn(
      "px-3 py-1 rounded-full text-sm flex items-center",
      statusStyles[status],
      className
    )}>
      <span className={cn(
        "inline-block w-2 h-2 rounded-full mr-2",
        {
          "bg-state-success": status === "active",
          "bg-state-warning": status === "warning",
          "bg-state-error": status === "error",
          "bg-accent-600": status === "processing"
        }
      )}></span>
      {text}
    </span>
  );
}
