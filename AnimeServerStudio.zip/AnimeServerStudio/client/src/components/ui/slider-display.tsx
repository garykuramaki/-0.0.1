import { useEffect, useState } from 'react';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';

interface SliderDisplayProps {
  label: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  defaultValue: number;
  onChange: (value: number) => void;
}

export function SliderDisplay({
  label,
  unit,
  min,
  max,
  step,
  defaultValue,
  onChange,
}: SliderDisplayProps) {
  const [value, setValue] = useState<number>(defaultValue);

  useEffect(() => {
    onChange(value);
  }, [value, onChange]);

  return (
    <div className="mb-6">
      <div className="flex justify-between mb-2">
        <Label className="font-medium">{label}</Label>
        <span className="text-dark-500">
          <span>{value}</span> {unit}
        </span>
      </div>
      <Slider
        min={min}
        max={max}
        step={step}
        value={[value]}
        onValueChange={(values) => setValue(values[0])}
        className="w-full h-2 bg-light-200 rounded-lg cursor-pointer"
      />
      <div className="flex justify-between text-sm text-dark-500 mt-1">
        <span>{min} {unit}</span>
        <span>{max} {unit}</span>
      </div>
    </div>
  );
}
