import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type ServerType = "web" | "database" | "ai";

export type ServerResource = {
  storage: number; // in GB
  ram: number; // in GB
  cpu: number; // number of vCPUs
  gpu?: string; // GPU model
};

export type ServerStatus = "active" | "pending" | "stopped" | "processing";

export type Server = {
  id: string;
  name: string;
  type: ServerType;
  resources: ServerResource;
  status: ServerStatus;
  uptime: number; // in minutes
  persistentMode?: boolean; // استمرارية السيرفر حتى بعد إغلاق الموقع
  apiKey?: string; // مفتاح API خاص بالسيرفر
  usage?: {
    cpu: number; // percentage
    ram: number; // used RAM in GB
    storage: number; // used storage in GB
    gpu?: number; // percentage
  };
};

export type AnimeEpisode = {
  id: string;
  title: string;
  duration: string;
  createdAt: string;
  size: string;
  status: "completed" | "processing" | "failed";
};

export type GPUOption = {
  model: string;
  vram: number;
  price: number;
  description: string;
};

export const gpuOptions: GPUOption[] = [
  {
    model: "NVIDIA T4",
    vram: 16,
    price: 0.5,
    description: "مناسب للتدريب المتوسط"
  },
  {
    model: "NVIDIA A100",
    vram: 40,
    price: 3.5,
    description: "أداء ممتاز لإنشاء الأنمي"
  },
  {
    model: "NVIDIA A10G",
    vram: 24,
    price: 1.5,
    description: "توازن بين الأداء والتكلفة"
  }
];

export const calculateServerCost = (resources: ServerResource): { monthly: number, gpuHourly?: number } => {
  // تم تغيير التكلفة لتكون مجانية
  const monthlyCost = 0;
  const gpuHourlyCost = 0;
  
  return {
    monthly: monthlyCost,
    gpuHourly: gpuHourlyCost
  };
};

export function formatTime(minutes: number): string {
  if (minutes < 60) {
    return `${minutes} دقيقة`;
  }
  
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  
  if (hours < 24) {
    return `${hours} ساعة${remainingMinutes > 0 ? `، ${remainingMinutes} دقيقة` : ''}`;
  }
  
  const days = Math.floor(hours / 24);
  const remainingHours = hours % 24;
  
  return `${days} أيام${remainingHours > 0 ? `، ${remainingHours} ساعة` : ''}`;
}
