import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { ResourceMeter } from '@/components/ui/resource-meter';
import { ServerStatusBadge } from '@/components/ui/server-status-badge';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export default function AIServer() {
  const { toast } = useToast();
  
  // AI Server Status
  const [serverStatus] = useState({
    status: 'active',
    resources: {
      cpu: { usage: 65, total: 100 },
      memory: { usage: 22, total: 40 },
      storage: { usage: 156, total: 500 },
      gpu: { usage: 87, total: 100 }
    },
    uptime: '3 أيام، 8 ساعات'
  });
  
  // Form state
  const [animeForm, setAnimeForm] = useState({
    title: '',
    scenario: '',
    style: 'traditional',
    duration: '30',
    characters: '',
    resolution: '1080p',
    options: {
      subtitles: false,
      voiceover: false,
      customMusic: false,
      visualEffects: false
    }
  });
  
  // Handle form changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setAnimeForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setAnimeForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleCheckboxChange = (option: string) => {
    setAnimeForm(prev => ({
      ...prev,
      options: {
        ...prev.options,
        [option]: !prev.options[option as keyof typeof prev.options]
      }
    }));
  };
  
  // Create anime episode
  const createAnimeMutation = useMutation({
    mutationFn: (animeData: any) => {
      return apiRequest('POST', '/api/anime/episodes', animeData);
    },
    onSuccess: () => {
      toast({
        title: "تم بدء إنشاء الحلقة بنجاح",
        description: "سيتم إعلامك عند اكتمال المعالجة",
      });
      // Reset form
      setAnimeForm({
        title: '',
        scenario: '',
        style: 'traditional',
        duration: '30',
        characters: '',
        resolution: '1080p',
        options: {
          subtitles: false,
          voiceover: false,
          customMusic: false,
          visualEffects: false
        }
      });
    },
    onError: (error) => {
      toast({
        title: "فشل في بدء إنشاء الحلقة",
        description: error.message || "حدث خطأ أثناء محاولة إنشاء الحلقة. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createAnimeMutation.mutate(animeForm);
  };
  
  // Restart server mutation
  const restartServerMutation = useMutation({
    mutationFn: () => {
      return apiRequest('POST', '/api/servers/ai/restart', {});
    },
    onSuccess: () => {
      toast({
        title: "تم إعادة تشغيل السيرفر",
        description: "سيكون السيرفر متاحًا في غضون دقائق",
      });
    }
  });
  
  // Stop server mutation
  const stopServerMutation = useMutation({
    mutationFn: () => {
      return apiRequest('POST', '/api/servers/ai/stop', {});
    },
    onSuccess: () => {
      toast({
        title: "تم إيقاف السيرفر",
        description: "تم إيقاف السيرفر بنجاح",
      });
    }
  });
  
  return (
    <div id="ai-server-section" className="mb-12">
      <h2 className="text-2xl font-bold mb-6">سيرفر الذكاء الاصطناعي لإنشاء حلقات الأنمي</h2>
      
      <Card className="mb-8">
        <CardContent className="p-6">
          {/* Server Status */}
          <div className="mb-8 border-b border-light-200 pb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">حالة سيرفر الذكاء الاصطناعي</h3>
              <ServerStatusBadge 
                status={serverStatus.status === 'active' ? 'active' : 'warning'} 
                text={serverStatus.status === 'active' ? 'نشط' : 'غير نشط'} 
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <ResourceMeter
                label="المعالج"
                value={`${serverStatus.resources.cpu.usage}% استخدام`}
                percentage={serverStatus.resources.cpu.usage}
                colorClass="bg-primary-500"
              />
              
              <ResourceMeter
                label="الذاكرة"
                value={`${serverStatus.resources.memory.usage} GB / ${serverStatus.resources.memory.total} GB`}
                percentage={(serverStatus.resources.memory.usage / serverStatus.resources.memory.total) * 100}
                colorClass="bg-accent-500"
              />
              
              <ResourceMeter
                label="التخزين"
                value={`${serverStatus.resources.storage.usage} GB / ${serverStatus.resources.storage.total} GB`}
                percentage={(serverStatus.resources.storage.usage / serverStatus.resources.storage.total) * 100}
                colorClass="bg-secondary-500"
              />
              
              <ResourceMeter
                label="GPU"
                value={`${serverStatus.resources.gpu.usage}% استخدام`}
                percentage={serverStatus.resources.gpu.usage}
                colorClass="bg-state-warning"
                animate={true}
              />
            </div>
            
            <div className="flex justify-between items-center">
              <div className="text-sm text-dark-500">
                وقت التشغيل: {serverStatus.uptime}
              </div>
              <div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mr-2"
                  onClick={() => restartServerMutation.mutate()}
                  disabled={restartServerMutation.isPending}
                >
                  {restartServerMutation.isPending ? 'جاري إعادة التشغيل...' : 'إعادة تشغيل'}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => stopServerMutation.mutate()}
                  disabled={stopServerMutation.isPending}
                >
                  {stopServerMutation.isPending ? 'جاري الإيقاف...' : 'إيقاف'}
                </Button>
              </div>
            </div>
          </div>
          
          {/* Anime Generation Form */}
          <div>
            <h3 className="text-lg font-medium mb-4">إنشاء حلقة أنمي جديدة</h3>
            
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <Label htmlFor="title" className="block font-medium mb-2">عنوان الحلقة</Label>
                <Input
                  id="title" 
                  name="title"
                  value={animeForm.title}
                  onChange={handleInputChange}
                  placeholder="أدخل عنوان الحلقة"
                  className="w-full border border-light-300 rounded-lg"
                />
              </div>
              
              <div>
                <Label htmlFor="scenario" className="block font-medium mb-2">وصف السيناريو</Label>
                <Textarea
                  id="scenario" 
                  name="scenario"
                  value={animeForm.scenario}
                  onChange={handleInputChange}
                  placeholder="اكتب وصفًا تفصيليًا للسيناريو والأحداث"
                  className="w-full border border-light-300 rounded-lg h-32"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="style" className="block font-medium mb-2">أسلوب الرسم</Label>
                  <Select
                    value={animeForm.style}
                    onValueChange={(value) => handleSelectChange('style', value)}
                  >
                    <SelectTrigger id="style" className="w-full">
                      <SelectValue placeholder="اختر أسلوب الرسم" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="traditional">الأسلوب الياباني التقليدي</SelectItem>
                      <SelectItem value="ghibli">أسلوب استوديو غيبلي</SelectItem>
                      <SelectItem value="shonen">أسلوب شونين معاصر</SelectItem>
                      <SelectItem value="custom">أسلوب خاص (مخصص)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="duration" className="block font-medium mb-2">المدة الزمنية</Label>
                  <Select
                    value={animeForm.duration}
                    onValueChange={(value) => handleSelectChange('duration', value)}
                  >
                    <SelectTrigger id="duration" className="w-full">
                      <SelectValue placeholder="اختر المدة الزمنية" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 دقيقة (قياسي)</SelectItem>
                      <SelectItem value="15">15 دقيقة (قصير)</SelectItem>
                      <SelectItem value="45">45 دقيقة (مطول)</SelectItem>
                      <SelectItem value="60">60 دقيقة (فيلم قصير)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="characters" className="block font-medium mb-2">الشخصيات الرئيسية</Label>
                  <Input
                    id="characters" 
                    name="characters"
                    value={animeForm.characters}
                    onChange={handleInputChange}
                    placeholder="أدخل أسماء الشخصيات مفصولة بفواصل"
                    className="w-full border border-light-300 rounded-lg"
                  />
                </div>
                
                <div>
                  <Label htmlFor="resolution" className="block font-medium mb-2">دقة الفيديو</Label>
                  <Select
                    value={animeForm.resolution}
                    onValueChange={(value) => handleSelectChange('resolution', value)}
                  >
                    <SelectTrigger id="resolution" className="w-full">
                      <SelectValue placeholder="اختر دقة الفيديو" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1080p">1080p (FHD)</SelectItem>
                      <SelectItem value="720p">720p (HD)</SelectItem>
                      <SelectItem value="4k">4K (UHD)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label className="block font-medium mb-2">إعدادات متقدمة</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <Checkbox 
                      id="subtitles" 
                      checked={animeForm.options.subtitles}
                      onCheckedChange={() => handleCheckboxChange('subtitles')}
                    />
                    <label htmlFor="subtitles" className="mr-2">إضافة ترجمة عربية</label>
                  </div>
                  
                  <div className="flex items-center">
                    <Checkbox 
                      id="voiceover" 
                      checked={animeForm.options.voiceover}
                      onCheckedChange={() => handleCheckboxChange('voiceover')}
                    />
                    <label htmlFor="voiceover" className="mr-2">دبلجة عربية</label>
                  </div>
                  
                  <div className="flex items-center">
                    <Checkbox 
                      id="customMusic" 
                      checked={animeForm.options.customMusic}
                      onCheckedChange={() => handleCheckboxChange('customMusic')}
                    />
                    <label htmlFor="customMusic" className="mr-2">موسيقى تصويرية مخصصة</label>
                  </div>
                  
                  <div className="flex items-center">
                    <Checkbox 
                      id="visualEffects" 
                      checked={animeForm.options.visualEffects}
                      onCheckedChange={() => handleCheckboxChange('visualEffects')}
                    />
                    <label htmlFor="visualEffects" className="mr-2">مؤثرات بصرية متقدمة</label>
                  </div>
                </div>
              </div>
              
              <div className="bg-light-100 rounded-lg p-4">
                <h4 className="font-medium mb-2">الوقت التقديري والتكلفة</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <span className="text-dark-500">وقت المعالجة التقديري</span>
                  <span>~2 ساعات</span>
                  
                  <span className="text-dark-500">التكلفة التقديرية</span>
                  <span className="text-secondary-500 font-bold">مجاناً (خدمة مجانية بالكامل)</span>
                </div>
              </div>
              
              <div className="flex justify-end space-x-3 space-x-reverse">
                <Button 
                  type="button" 
                  variant="outline"
                  disabled={createAnimeMutation.isPending}
                >
                  حفظ كمسودة
                </Button>
                <Button 
                  type="submit"
                  disabled={createAnimeMutation.isPending}
                >
                  {createAnimeMutation.isPending ? (
                    <>
                      <span className="material-icons animate-spin mr-1">refresh</span>
                      جاري الإنشاء...
                    </>
                  ) : (
                    "بدء الإنشاء"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
