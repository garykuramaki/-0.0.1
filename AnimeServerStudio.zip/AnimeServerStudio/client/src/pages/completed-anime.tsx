import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { type AnimeEpisode } from '@/lib/utils';

export default function CompletedAnime() {
  const { toast } = useToast();
  const [page, setPage] = useState(1);
  const pageSize = 20;
  const [episodes, setEpisodes] = useState<AnimeEpisode[]>([]);
  const [totalEpisodes, setTotalEpisodes] = useState(1500);

  const { isLoading, refetch } = useQuery({
    queryKey: [`/api/anime/episodes?page=${page}&pageSize=${pageSize}`],
    onSuccess: (data) => {
      setEpisodes(data.episodes);
      setTotalEpisodes(data.total);
    },
    onError: () => {
      // For development purposes - local mock data
      setEpisodes(getMockEpisodes());
    }
  });

  const totalPages = Math.ceil(totalEpisodes / pageSize);

  const downloadMutation = useMutation({
    mutationFn: (episodeId: string) => {
      return apiRequest('GET', `/api/anime/episodes/${episodeId}/download`, undefined);
    },
    onSuccess: () => {
      toast({
        title: "جاري التحميل",
        description: "بدأ تحميل الحلقة",
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (episodeId: string) => {
      return apiRequest('DELETE', `/api/anime/episodes/${episodeId}`, undefined);
    },
    onSuccess: () => {
      toast({
        title: "تم الحذف بنجاح",
        description: "تم حذف الحلقة بنجاح",
      });
      refetch();
    }
  });

  const handleDelete = (id: string) => {
    if (window.confirm("هل أنت متأكد من أنك تريد حذف هذه الحلقة؟")) {
      deleteMutation.mutate(id);
    }
  };

  const handleDownload = (id: string) => {
    downloadMutation.mutate(id);
  };
  
  const handleDownloadZip = () => {
    // فتح رابط التنزيل في نافذة جديدة
    window.open('/api/download/zip', '_blank');
    
    toast({
      title: "جاري تحميل الملف المضغوط",
      description: "بدأ تحميل كافة حلقات الأنمي المحددة",
    });
  };

  return (
    <div id="completed-anime">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">حلقات الأنمي المكتملة</h2>
        <button
          className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md"
          onClick={handleDownloadZip}
        >
          <span className="material-icons text-sm">download</span>
          تنزيل الكل كملف مضغوط
        </button>
      </div>
      
      <Card>
        <CardContent className="p-6">
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-light-200">
                  <th className="text-right py-3 px-4">عنوان الحلقة</th>
                  <th className="text-right py-3 px-4">المدة</th>
                  <th className="text-right py-3 px-4">تاريخ الإنشاء</th>
                  <th className="text-right py-3 px-4">الحجم</th>
                  <th className="text-right py-3 px-4">الحالة</th>
                  <th className="text-right py-3 px-4">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center">
                      <div className="flex justify-center">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
                      </div>
                    </td>
                  </tr>
                ) : episodes.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-dark-500">
                      لم يتم العثور على أي حلقات
                    </td>
                  </tr>
                ) : (
                  episodes.map((episode) => (
                    <tr key={episode.id} className="border-b border-light-200 hover:bg-light-50">
                      <td className="py-3 px-4">{episode.title}</td>
                      <td className="py-3 px-4">{episode.duration}</td>
                      <td className="py-3 px-4">{episode.createdAt}</td>
                      <td className="py-3 px-4">{episode.size}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 bg-state-success bg-opacity-10 text-state-success rounded-full text-sm">
                          {episode.status === 'completed' ? 'مكتمل' : 
                           episode.status === 'processing' ? 'قيد المعالجة' : 'فشل'}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex space-x-2 space-x-reverse">
                          <button 
                            className="p-1 hover:bg-light-100 rounded"
                            onClick={() => handleDownload(episode.id)}
                            disabled={downloadMutation.isPending}
                          >
                            <span className="material-icons text-primary-600">download</span>
                          </button>
                          <button className="p-1 hover:bg-light-100 rounded">
                            <span className="material-icons text-dark-500">edit</span>
                          </button>
                          <button 
                            className="p-1 hover:bg-light-100 rounded"
                            onClick={() => handleDelete(episode.id)}
                            disabled={deleteMutation.isPending}
                          >
                            <span className="material-icons text-dark-500">delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          
          <div className="flex justify-between items-center mt-6 text-sm">
            <div className="text-dark-500">
              إظهار {(page - 1) * pageSize + 1}-{Math.min(page * pageSize, totalEpisodes)} من {totalEpisodes} حلقة
            </div>
            <div className="flex space-x-1 space-x-reverse">
              <button 
                className="w-8 h-8 flex items-center justify-center rounded border border-light-300 bg-white"
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page <= 1}
              >
                <span className="material-icons text-dark-500 text-sm">chevron_right</span>
              </button>
              
              {Array.from({ length: Math.min(totalPages, 3) }).map((_, index) => (
                <button 
                  key={index}
                  className={`w-8 h-8 flex items-center justify-center rounded border border-light-300 ${
                    page === index + 1 ? 'bg-primary-50 text-primary-600' : 'bg-white'
                  }`}
                  onClick={() => setPage(index + 1)}
                >
                  {index + 1}
                </button>
              ))}
              
              <button 
                className="w-8 h-8 flex items-center justify-center rounded border border-light-300 bg-white"
                onClick={() => setPage(Math.min(totalPages, page + 1))}
                disabled={page >= totalPages}
              >
                <span className="material-icons text-dark-500 text-sm">chevron_left</span>
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// For development purposes - local mock data
function getMockEpisodes(): AnimeEpisode[] {
  return [
    {
      id: "ep1",
      title: "رحلة البطل - الحلقة 1",
      duration: "30:12",
      createdAt: "22/04/2023",
      size: "1.2 GB",
      status: "completed"
    },
    {
      id: "ep2",
      title: "المغامرة الغامضة - الحلقة 1",
      duration: "28:45",
      createdAt: "20/04/2023",
      size: "1.1 GB",
      status: "completed"
    },
    {
      id: "ep3",
      title: "عالم الخيال - الحلقة 2",
      duration: "31:20",
      createdAt: "15/04/2023",
      size: "1.3 GB",
      status: "completed"
    },
    {
      id: "ep4",
      title: "رحلة البطل - الحلقة 2",
      duration: "29:55",
      createdAt: "10/04/2023",
      size: "1.2 GB",
      status: "completed"
    }
  ];
}
