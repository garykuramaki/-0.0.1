import React, { useState, useEffect } from 'react';
import { SliderDisplay } from '@/components/ui/slider-display';
import { Card, CardContent } from '@/components/ui/card';
import { ServerResource, gpuOptions, calculateServerCost } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

type ServerType = 'web' | 'database' | 'ai';

export default function CreateServer() {
  const { toast } = useToast();
  const [serverType, setServerType] = useState<ServerType>('web');
  const [resources, setResources] = useState<ServerResource>({
    storage: 100,
    ram: 8,
    cpu: 2
  });
  const [selectedGpu, setSelectedGpu] = useState<string | undefined>('NVIDIA A100');
  const [additionalOptions, setAdditionalOptions] = useState({
    backup: false,
    monitoring: false,
    autoScale: false,
    firewall: false,
    persistentMode: true
  });
  
  const [cost, setCost] = useState<{ monthly: number, gpuHourly?: number }>({ monthly: 0 });
  
  useEffect(() => {
    const newResources = { ...resources };
    if (serverType === 'ai' && selectedGpu) {
      newResources.gpu = selectedGpu;
    } else {
      delete newResources.gpu;
    }
    
    setCost(calculateServerCost(newResources));
  }, [resources, serverType, selectedGpu]);
  
  const handleResourceChange = (key: keyof ServerResource, value: number) => {
    setResources(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  const handleCheckboxChange = (key: string) => {
    setAdditionalOptions(prev => ({
      ...prev,
      [key]: !prev[key as keyof typeof additionalOptions]
    }));
  };

  const createServerMutation = useMutation({
    mutationFn: (serverData: any) => {
      return apiRequest('POST', '/api/servers', serverData);
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء السيرفر بنجاح",
        description: "سيكون السيرفر الجديد متاحًا في غضون دقائق",
      });
    },
    onError: (error) => {
      toast({
        title: "فشل إنشاء السيرفر",
        description: error.message || "حدث خطأ أثناء إنشاء السيرفر. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    }
  });

  const handleCreateServer = () => {
    const serverData = {
      name: serverName,
      type: serverType,
      resources: {
        ...resources,
        ...(serverType === 'ai' && selectedGpu ? { gpu: selectedGpu } : {})
      },
      backup: additionalOptions.backup,
      monitoring: additionalOptions.monitoring,
      autoScale: additionalOptions.autoScale,
      firewall: additionalOptions.firewall,
      persistentMode: additionalOptions.persistentMode
    };
    
    createServerMutation.mutate(serverData);
  };
  
  const handleReset = () => {
    setResources({
      storage: 100,
      ram: 8,
      cpu: 2
    });
    setSelectedGpu('NVIDIA A100');
    setAdditionalOptions({
      backup: false,
      monitoring: false,
      autoScale: false,
      firewall: false,
      persistentMode: true // الإبقاء على وضع الاستمرارية مفعلاً افتراضيًا
    });
  };
  
  return (
    <div id="create-server" className="mb-12">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">إنشاء سيرفر جديد</h2>
      </div>
      
      <Card>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Server Type Selector */}
            <div className="lg:col-span-3">
              <h3 className="text-lg font-medium mb-4">اختر نوع السيرفر</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div 
                  className={`border rounded-lg p-4 flex flex-col items-center cursor-pointer ${
                    serverType === 'web' 
                      ? 'border-primary-500 bg-primary-50' 
                      : 'border-light-300 hover:border-primary-500 hover:bg-primary-50'
                  }`}
                  onClick={() => setServerType('web')}
                >
                  <span className={`material-icons text-4xl ${serverType === 'web' ? 'text-primary-500' : 'text-dark-500'} mb-2`}>
                    storage
                  </span>
                  <h4 className="font-medium text-center">سيرفر ويب</h4>
                  <p className="text-sm text-dark-500 text-center mt-2">لاستضافة المواقع والتطبيقات</p>
                </div>
                
                <div 
                  className={`border rounded-lg p-4 flex flex-col items-center cursor-pointer ${
                    serverType === 'database' 
                      ? 'border-primary-500 bg-primary-50' 
                      : 'border-light-300 hover:border-primary-500 hover:bg-primary-50'
                  }`}
                  onClick={() => setServerType('database')}
                >
                  <span className={`material-icons text-4xl ${serverType === 'database' ? 'text-primary-500' : 'text-dark-500'} mb-2`}>
                    dns
                  </span>
                  <h4 className="font-medium text-center">سيرفر قواعد البيانات</h4>
                  <p className="text-sm text-dark-500 text-center mt-2">لتخزين ومعالجة البيانات</p>
                </div>
                
                <div 
                  className={`border rounded-lg p-4 flex flex-col items-center cursor-pointer ${
                    serverType === 'ai' 
                      ? 'border-primary-500 bg-primary-50' 
                      : 'border-light-300 hover:border-primary-500 hover:bg-primary-50'
                  }`}
                  onClick={() => setServerType('ai')}
                >
                  <span className={`material-icons text-4xl ${serverType === 'ai' ? 'text-primary-500' : 'text-dark-500'} mb-2`}>
                    memory
                  </span>
                  <h4 className="font-medium text-center">سيرفر الذكاء الاصطناعي</h4>
                  <p className="text-sm text-dark-500 text-center mt-2">للتعلم العميق ومعالجة النماذج</p>
                </div>
              </div>
            </div>
            
            {/* Server Configuration */}
            <div className="lg:col-span-3">
              <div className="border-b border-light-200 pb-4 mb-6">
                <h3 className="text-lg font-medium mb-4">تكوين الموارد</h3>
              </div>
              
              {/* Resources Sliders */}
              <SliderDisplay 
                label="مساحة التخزين" 
                unit="GB" 
                min={50} 
                max={1000} 
                step={10} 
                defaultValue={resources.storage}
                onChange={(value) => handleResourceChange('storage', value)} 
              />
              
              <SliderDisplay 
                label="ذاكرة الوصول العشوائي (RAM)" 
                unit="GB" 
                min={2} 
                max={64} 
                step={2} 
                defaultValue={resources.ram}
                onChange={(value) => handleResourceChange('ram', value)} 
              />
              
              <SliderDisplay 
                label="المعالجات (vCPU)" 
                unit="vCPU" 
                min={1} 
                max={16} 
                step={1} 
                defaultValue={resources.cpu}
                onChange={(value) => handleResourceChange('cpu', value)} 
              />
              
              {/* GPU Selection for AI */}
              {serverType === 'ai' && (
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-4">
                    <label className="font-medium">بطاقات المعالجة الرسومية (GPU)</label>
                    <span className="text-dark-500">اختياري لسيرفرات الذكاء الاصطناعي</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {gpuOptions.map((gpu) => (
                      <div 
                        key={gpu.model}
                        className={`border rounded-lg p-4 cursor-pointer ${
                          selectedGpu === gpu.model 
                            ? 'border-primary-500 bg-primary-50' 
                            : 'border-light-200 hover:border-primary-500'
                        }`}
                        onClick={() => setSelectedGpu(gpu.model)}
                      >
                        <div className="flex justify-between mb-2">
                          <h4 className="font-medium">{gpu.model}</h4>
                          <span className="text-dark-500">${gpu.price}/ساعة</span>
                        </div>
                        <p className="text-sm text-dark-500">{gpu.vram} GB VRAM</p>
                        <p className="text-sm text-dark-500">{gpu.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Additional Options */}
              <div className="mb-8">
                <h3 className="font-medium mb-4">خيارات إضافية</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <Checkbox 
                      id="backup" 
                      checked={additionalOptions.backup}
                      onCheckedChange={() => handleCheckboxChange('backup')}
                    />
                    <label htmlFor="backup" className="mr-2">نسخ احتياطي تلقائي يومي</label>
                  </div>
                  
                  <div className="flex items-center">
                    <Checkbox 
                      id="monitoring" 
                      checked={additionalOptions.monitoring}
                      onCheckedChange={() => handleCheckboxChange('monitoring')}
                    />
                    <label htmlFor="monitoring" className="mr-2">مراقبة متقدمة</label>
                  </div>
                  
                  <div className="flex items-center">
                    <Checkbox 
                      id="autoScale" 
                      checked={additionalOptions.autoScale}
                      onCheckedChange={() => handleCheckboxChange('autoScale')}
                    />
                    <label htmlFor="autoScale" className="mr-2">تغيير الحجم تلقائيًا</label>
                  </div>
                  
                  <div className="flex items-center">
                    <Checkbox 
                      id="firewall" 
                      checked={additionalOptions.firewall}
                      onCheckedChange={() => handleCheckboxChange('firewall')}
                    />
                    <label htmlFor="firewall" className="mr-2">جدار حماية متقدم</label>
                  </div>
                  
                  <div className="flex items-center">
                    <Checkbox 
                      id="persistentMode" 
                      checked={additionalOptions.persistentMode}
                      onCheckedChange={() => handleCheckboxChange('persistentMode')}
                    />
                    <label htmlFor="persistentMode" className="mr-2">
                      <span className="flex items-center">
                        <span className="material-icons text-xs mr-1 text-secondary-500">all_inclusive</span>
                        وضع الاستمرارية
                      </span>
                      <div className="text-xs text-dark-400 mr-6">سيظل السيرفر نشطًا حتى بعد إغلاق الموقع</div>
                    </label>
                  </div>
                </div>
              </div>
              
              {/* Cost Estimate */}
              <div className="bg-light-100 rounded-lg p-4 mb-6">
                <h3 className="font-medium mb-2">خطة الخدمة الحالية</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <span className="text-dark-500">التخزين ({resources.storage} GB)</span>
                  <span className="text-left text-secondary-500 font-bold">مجاناً</span>
                  
                  <span className="text-dark-500">ذاكرة الوصول العشوائي ({resources.ram} GB)</span>
                  <span className="text-left text-secondary-500 font-bold">مجاناً</span>
                  
                  <span className="text-dark-500">المعالجات ({resources.cpu} vCPU)</span>
                  <span className="text-left text-secondary-500 font-bold">مجاناً</span>
                  
                  {selectedGpu && serverType === 'ai' && (
                    <React.Fragment>
                      <span className="text-dark-500">بطاقة المعالجة الرسومية ({selectedGpu})</span>
                      <span className="text-left text-secondary-500 font-bold">
                        مجاناً
                      </span>
                    </React.Fragment>
                  )}
                  
                  <span className="text-dark-500">الخيارات الإضافية</span>
                  <span className="text-left text-secondary-500 font-bold">مجاناً</span>
                  
                  <div className="col-span-2 border-t border-light-300 my-2"></div>
                  
                  <span className="font-medium">الإجمالي الشهري</span>
                  <span className="font-bold text-left text-secondary-500">مجاناً بالكامل</span>
                  
                  <span className="text-accent-600 text-xs col-span-2">* جميع الخدمات مجانية بحد 1500 حلقة أنمي</span>
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex justify-end space-x-3 space-x-reverse">
                <Button 
                  variant="outline" 
                  onClick={handleReset}
                  disabled={createServerMutation.isPending}
                >
                  إعادة تعيين
                </Button>
                <Button 
                  onClick={handleCreateServer} 
                  disabled={createServerMutation.isPending}
                  className={createServerMutation.isPending ? "opacity-70" : ""}
                >
                  {createServerMutation.isPending ? (
                    <>
                      <span className="material-icons animate-spin mr-1">refresh</span>
                      جاري الإنشاء...
                    </>
                  ) : (
                    "إنشاء السيرفر"
                  )}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
