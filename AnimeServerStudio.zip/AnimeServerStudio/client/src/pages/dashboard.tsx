import React, { useState, useEffect } from 'react';
import { StatsCard } from '@/components/dashboard/stats-card';
import { ServerCard } from '@/components/dashboard/server-card';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { type Server } from '@/lib/utils';

export default function Dashboard() {
  const [, navigate] = useLocation();
  const [servers, setServers] = useState<Server[]>([]);
  
  // Fetch servers data
  const { data, isLoading } = useQuery({ 
    queryKey: ['/api/servers'],
    onError: () => {
      // If there's an error fetching, use local mock data
      setServers(getMockServers());
    }
  });
  
  useEffect(() => {
    if (data) {
      setServers(data);
    } else if (!isLoading) {
      setServers(getMockServers());
    }
  }, [data, isLoading]);

  return (
    <>
      <div id="dashboard" className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">لوحة التحكم</h1>
          <a 
            href="/api/download/zip"
            download
            className="flex items-center gap-2 bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md"
            target="_blank"
            rel="noopener noreferrer"
          >
            <span className="material-icons text-sm">file_download</span>
            تنزيل ملف مضغوط
          </a>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatsCard 
            title="السيرفرات النشطة" 
            value={servers.filter(s => s.status === "active").length} 
            icon="cloud_done" 
            statusText="جميع السيرفرات تعمل" 
            statusColor="secondary" 
          />
          
          <StatsCard 
            title="الاستخدام الحالي" 
            value="68%" 
            icon="speed" 
            statusText="منذ 5 دقائق" 
            statusColor="dark" 
          />
          
          <StatsCard 
            title="حلقات الأنمي" 
            value="12" 
            icon="movie" 
            statusText="3 قيد المعالجة" 
            statusColor="accent" 
          />
        </div>
      </div>
      
      <div id="active-servers" className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">السيرفرات النشطة</h2>
          <button 
            className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center"
            onClick={() => navigate('/create-server')}
          >
            <span className="material-icons mr-1">add</span>
            إنشاء سيرفر
          </button>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center p-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {servers.map((server) => (
              <ServerCard key={server.id} server={server} />
            ))}
          </div>
        )}
      </div>
    </>
  );
}

// Mock data function for development purposes
function getMockServers(): Server[] {
  return [
    {
      id: "server1",
      name: "سيرفر الويب الرئيسي",
      type: "web",
      resources: {
        storage: 100,
        ram: 8,
        cpu: 4
      },
      status: "active",
      uptime: 21600 // 15 days in minutes
    },
    {
      id: "server2",
      name: "سيرفر قاعدة البيانات",
      type: "database",
      resources: {
        storage: 250,
        ram: 16,
        cpu: 2
      },
      status: "active",
      uptime: 11520 // 8 days in minutes
    },
    {
      id: "server3",
      name: "سيرفر الذكاء الاصطناعي لإنشاء الأنمي",
      type: "ai",
      resources: {
        storage: 500,
        ram: 40,
        cpu: 8,
        gpu: "NVIDIA A100"
      },
      status: "processing",
      uptime: 4320, // 3 days in minutes
      usage: {
        cpu: 65,
        ram: 22,
        storage: 156,
        gpu: 72
      }
    }
  ];
}
