import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertServerSchema, insertAnimeEpisodeSchema } from "@shared/schema";
import * as fs from 'fs-extra';
import * as path from 'path';
import archiver from 'archiver';

export async function registerRoutes(app: Express): Promise<Server> {
  // Servers routes
  app.get("/api/servers", async (req, res) => {
    try {
      const servers = await storage.getAllServers();
      res.json(servers);
    } catch (error) {
      res.status(500).json({ message: "Error fetching servers" });
    }
  });

  app.post("/api/servers", async (req, res) => {
    try {
      const result = insertServerSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid server data", 
          errors: result.error.format() 
        });
      }
      
      // Store userId as 1 for demo purposes (would normally come from auth)
      const serverData = { ...result.data, userId: 1 };
      const newServer = await storage.createServer(serverData);
      
      res.status(201).json(newServer);
    } catch (error) {
      res.status(500).json({ message: "Error creating server" });
    }
  });

  app.get("/api/servers/:id", async (req, res) => {
    try {
      const server = await storage.getServer(parseInt(req.params.id));
      
      if (!server) {
        return res.status(404).json({ message: "Server not found" });
      }
      
      res.json(server);
    } catch (error) {
      res.status(500).json({ message: "Error fetching server" });
    }
  });

  app.post("/api/servers/ai/restart", async (req, res) => {
    try {
      // In a real app, this would actually restart the server
      // For now, simulate restarting
      setTimeout(() => {
        // Logic to update server status would go here
      }, 5000);
      
      res.json({ message: "Server restart initiated" });
    } catch (error) {
      res.status(500).json({ message: "Error restarting server" });
    }
  });

  app.post("/api/servers/ai/stop", async (req, res) => {
    try {
      // In a real app, this would actually stop the server
      // For now, simulate stopping
      setTimeout(() => {
        // Logic to update server status would go here
      }, 2000);
      
      res.json({ message: "Server stop initiated" });
    } catch (error) {
      res.status(500).json({ message: "Error stopping server" });
    }
  });

  // Anime episodes routes
  app.get("/api/anime/episodes", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      
      const { episodes, total } = await storage.getAnimeEpisodes(page, pageSize);
      
      res.json({
        episodes,
        total,
        page,
        pageSize
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching anime episodes" });
    }
  });

  app.post("/api/anime/episodes", async (req, res) => {
    try {
      const result = insertAnimeEpisodeSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid anime episode data", 
          errors: result.error.format() 
        });
      }
      
      // Store userId as 1 for demo purposes (would normally come from auth)
      const episodeData = { ...result.data, userId: 1 };
      const newEpisode = await storage.createAnimeEpisode(episodeData);
      
      res.status(201).json(newEpisode);
    } catch (error) {
      res.status(500).json({ message: "Error creating anime episode" });
    }
  });

  app.get("/api/anime/episodes/:id", async (req, res) => {
    try {
      const episode = await storage.getAnimeEpisode(parseInt(req.params.id));
      
      if (!episode) {
        return res.status(404).json({ message: "Anime episode not found" });
      }
      
      res.json(episode);
    } catch (error) {
      res.status(500).json({ message: "Error fetching anime episode" });
    }
  });

  app.delete("/api/anime/episodes/:id", async (req, res) => {
    try {
      const success = await storage.deleteAnimeEpisode(parseInt(req.params.id));
      
      if (!success) {
        return res.status(404).json({ message: "Anime episode not found" });
      }
      
      res.json({ message: "Anime episode deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting anime episode" });
    }
  });

  app.get("/api/anime/episodes/:id/download", async (req, res) => {
    try {
      const episode = await storage.getAnimeEpisode(parseInt(req.params.id));
      
      if (!episode) {
        return res.status(404).json({ message: "Anime episode not found" });
      }
      
      // في تطبيق حقيقي، هذا سيقوم بتوليد رابط تنزيل أو بث الملف
      // الآن، هذا يقوم بمحاكاة تنزيل الملف
      res.json({ message: "Download initiated", episode });
    } catch (error) {
      res.status(500).json({ message: "Error downloading anime episode" });
    }
  });
  
  // مسار تنزيل الملف المضغوط
  app.get("/api/download/zip", async (req, res) => {
    try {
      // إنشاء مجلد مؤقت إذا لم يكن موجودًا
      const tempDir = path.join(__dirname, '..', 'temp');
      await fs.ensureDir(tempDir);
      
      // إنشاء ملف مضغوط مؤقت
      const zipFileName = `anime-episodes-${Date.now()}.zip`;
      const zipFilePath = path.join(tempDir, zipFileName);
      
      // إنشاء كاتب الملف المضغوط وإعداده
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', {
        zlib: { level: 9 } // مستوى ضغط أقصى
      });
      
      // إعداد معالجات الأحداث
      output.on('close', () => {
        console.log(`تم إنشاء ملف مضغوط بحجم ${archive.pointer()} بايت`);
        
        // إرسال الملف كتنزيل
        res.download(zipFilePath, zipFileName, (err) => {
          if (err) {
            console.error('خطأ في تنزيل الملف:', err);
          }
          
          // حذف الملف المؤقت بعد التنزيل
          fs.remove(zipFilePath).catch(err => {
            console.error('خطأ في حذف الملف المؤقت:', err);
          });
        });
      });
      
      archive.on('error', (err: Error) => {
        throw err;
      });
      
      // ربط الأرشيف بكاتب الملف
      archive.pipe(output);
      
      // محاكاة إضافة ملفات إلى الأرشيف
      // في تطبيق حقيقي، ستقوم بإضافة الملفات الفعلية من مصدر البيانات
      
      // إضافة ملف نصي كمثال
      const demoContent = 'هذا ملف تجريبي يحتوي على بيانات الأنمي.\n';
      archive.append(demoContent, { name: 'README.txt' });
      
      // محاكاة إضافة حلقات الأنمي
      const episodes = await storage.getAnimeEpisodes(1, 10);
      
      for (const episode of episodes.episodes) {
        // إنشاء ملف JSON يحتوي على معلومات الحلقة
        const episodeData = JSON.stringify(episode, null, 2);
        archive.append(episodeData, { name: `episode-${episode.id}/info.json` });
        
        // إضافة ملف نصي محاكي كملف فيديو (في التطبيق الحقيقي سيكون ملف فيديو)
        const demoVideoContent = `بيانات فيديو محاكاة لحلقة ${episode.title}`;
        archive.append(demoVideoContent, { name: `episode-${episode.id}/video.txt` });
      }
      
      // إنهاء عملية الأرشفة
      archive.finalize();
      
    } catch (error) {
      console.error('خطأ في إنشاء الملف المضغوط:', error);
      res.status(500).json({ message: "خطأ في إنشاء الملف المضغوط" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
