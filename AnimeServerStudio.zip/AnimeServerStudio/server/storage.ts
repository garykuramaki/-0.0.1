import { 
  users, type User, type InsertUser,
  servers, type Server, type InsertServer,
  animeEpisodes, type AnimeEpisode, type InsertAnimeEpisode 
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Server operations
  getAllServers(): Promise<Server[]>;
  getServer(id: number): Promise<Server | undefined>;
  getServersByUserId(userId: number): Promise<Server[]>;
  createServer(server: InsertServer): Promise<Server>;
  updateServer(id: number, server: Partial<Server>): Promise<Server | undefined>;
  deleteServer(id: number): Promise<boolean>;
  
  // Anime episode operations
  getAnimeEpisodes(page: number, pageSize: number): Promise<{ episodes: AnimeEpisode[], total: number }>;
  getAnimeEpisode(id: number): Promise<AnimeEpisode | undefined>;
  getAnimeEpisodesByUserId(userId: number): Promise<AnimeEpisode[]>;
  createAnimeEpisode(episode: InsertAnimeEpisode): Promise<AnimeEpisode>;
  updateAnimeEpisode(id: number, episode: Partial<AnimeEpisode>): Promise<AnimeEpisode | undefined>;
  deleteAnimeEpisode(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private servers: Map<number, Server>;
  private animeEpisodes: Map<number, AnimeEpisode>;
  private userId: number;
  private serverId: number;
  private episodeId: number;

  constructor() {
    this.users = new Map();
    this.servers = new Map();
    this.animeEpisodes = new Map();
    this.userId = 1;
    this.serverId = 1;
    this.episodeId = 1;
    
    // Initialize with some mock data
    this.initializeData();
  }

  private initializeData() {
    // Create a mock user
    const user: User = {
      id: this.userId++,
      username: 'ahmed',
      password: 'password123', // In real app, this would be hashed
      email: 'ahmed@example.com',
      createdAt: new Date()
    };
    this.users.set(user.id, user);
    
    // Create mock servers
    const webServer: Server = {
      id: this.serverId++,
      name: "سيرفر الويب الرئيسي",
      type: "web",
      storage: 100,
      ram: 8,
      cpu: 4,
      status: "active",
      createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 days ago
      uptime: 15 * 24 * 60, // 15 days in minutes
      backup: true,
      monitoring: true,
      autoScale: false,
      firewall: true,
      userId: user.id
    };
    
    const dbServer: Server = {
      id: this.serverId++,
      name: "سيرفر قاعدة البيانات",
      type: "database",
      storage: 250,
      ram: 16,
      cpu: 2,
      status: "active",
      createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000), // 8 days ago
      uptime: 8 * 24 * 60, // 8 days in minutes
      backup: true,
      monitoring: true,
      autoScale: true,
      firewall: true,
      userId: user.id
    };
    
    const aiServer: Server = {
      id: this.serverId++,
      name: "سيرفر الذكاء الاصطناعي لإنشاء الأنمي",
      type: "ai",
      storage: 500,
      ram: 40,
      cpu: 8,
      gpu: "NVIDIA A100",
      status: "processing",
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
      uptime: 3 * 24 * 60, // 3 days in minutes
      backup: true,
      monitoring: true,
      autoScale: false,
      firewall: true,
      userId: user.id
    };
    
    this.servers.set(webServer.id, webServer);
    this.servers.set(dbServer.id, dbServer);
    this.servers.set(aiServer.id, aiServer);
    
    // Create mock anime episodes
    const episodes = [
      {
        title: "رحلة البطل - الحلقة 1",
        scenario: "البطل يبدأ مغامرته في عالم غريب",
        style: "traditional",
        duration: 30,
        characters: "يوكي، هانا، كازو",
        resolution: "1080p",
        subtitles: true,
        voiceover: false,
        customMusic: true,
        visualEffects: true,
        status: "completed",
        createdAt: new Date(Date.now() - 22 * 24 * 60 * 60 * 1000),
        completedAt: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000),
        size: "1.2 GB",
        filePath: "/storage/episodes/ep1.mp4",
        userId: user.id
      },
      {
        title: "المغامرة الغامضة - الحلقة 1",
        scenario: "مجموعة من الأصدقاء يكتشفون سرًا غامضًا",
        style: "ghibli",
        duration: 28,
        characters: "ساكي، تومو، ميكا",
        resolution: "1080p",
        subtitles: true,
        voiceover: true,
        customMusic: false,
        visualEffects: true,
        status: "completed",
        createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
        completedAt: new Date(Date.now() - 19 * 24 * 60 * 60 * 1000),
        size: "1.1 GB",
        filePath: "/storage/episodes/ep2.mp4",
        userId: user.id
      },
      {
        title: "عالم الخيال - الحلقة 2",
        scenario: "رحلة في عالم الأحلام والخيال",
        style: "shonen",
        duration: 31,
        characters: "رين، آكي، سورا",
        resolution: "1080p",
        subtitles: true,
        voiceover: false,
        customMusic: true,
        visualEffects: true,
        status: "completed",
        createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
        completedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
        size: "1.3 GB",
        filePath: "/storage/episodes/ep3.mp4",
        userId: user.id
      },
      {
        title: "رحلة البطل - الحلقة 2",
        scenario: "البطل يواجه تحديات جديدة",
        style: "traditional",
        duration: 29,
        characters: "يوكي، هانا، كازو، تاكا",
        resolution: "1080p",
        subtitles: true,
        voiceover: false,
        customMusic: true,
        visualEffects: true,
        status: "completed",
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        completedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
        size: "1.2 GB",
        filePath: "/storage/episodes/ep4.mp4",
        userId: user.id
      }
    ];
    
    episodes.forEach(episode => {
      this.animeEpisodes.set(this.episodeId, { 
        ...episode, 
        id: this.episodeId 
      } as AnimeEpisode);
      this.episodeId++;
    });
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }
  
  // Server methods
  async getAllServers(): Promise<Server[]> {
    return Array.from(this.servers.values());
  }

  async getServer(id: number): Promise<Server | undefined> {
    return this.servers.get(id);
  }

  async getServersByUserId(userId: number): Promise<Server[]> {
    return Array.from(this.servers.values()).filter(
      server => server.userId === userId
    );
  }

  async createServer(server: InsertServer): Promise<Server> {
    const id = this.serverId++;
    // إنشاء مفتاح API فريد للسيرفر
    const apiKey = this.generateUniqueApiKey();
    
    const newServer: Server = { 
      ...server, 
      id, 
      createdAt: new Date(),
      status: "pending",
      uptime: 0,
      persistentMode: true, // تفعيل وضع الاستمرارية افتراضيًا
      apiKey: apiKey
    };
    this.servers.set(id, newServer);
    
    // Simulate server provisioning (would be an async job in a real app)
    setTimeout(() => {
      const server = this.servers.get(id);
      if (server) {
        server.status = "active";
        this.servers.set(id, server);
      }
    }, 10000);
    
    return newServer;
  }
  
  // توليد مفتاح API فريد
  private generateUniqueApiKey(): string {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const length = 32;
    let apiKey = '';
    
    for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      apiKey += characters.charAt(randomIndex);
    }
    
    // التحقق من عدم وجود نفس المفتاح لسيرفر آخر
    const exists = Array.from(this.servers.values()).some(server => server.apiKey === apiKey);
    if (exists) {
      return this.generateUniqueApiKey(); // إعادة المحاولة إذا كان المفتاح موجودًا بالفعل
    }
    
    return apiKey;
  }

  async updateServer(id: number, serverUpdate: Partial<Server>): Promise<Server | undefined> {
    const server = this.servers.get(id);
    if (!server) return undefined;
    
    const updatedServer = { ...server, ...serverUpdate };
    this.servers.set(id, updatedServer);
    return updatedServer;
  }

  async deleteServer(id: number): Promise<boolean> {
    return this.servers.delete(id);
  }
  
  // Anime episode methods
  async getAnimeEpisodes(page: number, pageSize: number): Promise<{ episodes: AnimeEpisode[], total: number }> {
    const allEpisodes = Array.from(this.animeEpisodes.values());
    const start = (page - 1) * pageSize;
    const end = start + pageSize;
    
    return {
      episodes: allEpisodes.slice(start, end),
      total: allEpisodes.length
    };
  }

  async getAnimeEpisode(id: number): Promise<AnimeEpisode | undefined> {
    return this.animeEpisodes.get(id);
  }

  async getAnimeEpisodesByUserId(userId: number): Promise<AnimeEpisode[]> {
    return Array.from(this.animeEpisodes.values()).filter(
      episode => episode.userId === userId
    );
  }

  async createAnimeEpisode(episode: InsertAnimeEpisode): Promise<AnimeEpisode> {
    const id = this.episodeId++;
    
    // Convert string duration to number
    let durationNum = typeof episode.duration === 'string' 
      ? parseInt(episode.duration) 
      : episode.duration;
    
    const newEpisode: AnimeEpisode = { 
      ...episode, 
      id, 
      duration: durationNum,
      createdAt: new Date(),
      status: "processing",
      size: "Pending",
      filePath: `/storage/episodes/ep${id}.mp4`
    };
    this.animeEpisodes.set(id, newEpisode);
    
    // Simulate processing (would be an async job in a real app)
    setTimeout(() => {
      const episode = this.animeEpisodes.get(id);
      if (episode) {
        const sizeMB = Math.floor(Math.random() * 400) + 800; // 800 - 1200 MB
        const updatedEpisode = { 
          ...episode, 
          status: "completed",
          completedAt: new Date(),
          size: `${(sizeMB / 1000).toFixed(1)} GB`
        };
        this.animeEpisodes.set(id, updatedEpisode);
      }
    }, 20000); // Simulate 20 second processing for demo
    
    return newEpisode;
  }

  async updateAnimeEpisode(id: number, episodeUpdate: Partial<AnimeEpisode>): Promise<AnimeEpisode | undefined> {
    const episode = this.animeEpisodes.get(id);
    if (!episode) return undefined;
    
    const updatedEpisode = { ...episode, ...episodeUpdate };
    this.animeEpisodes.set(id, updatedEpisode);
    return updatedEpisode;
  }

  async deleteAnimeEpisode(id: number): Promise<boolean> {
    return this.animeEpisodes.delete(id);
  }
}

export const storage = new MemStorage();
