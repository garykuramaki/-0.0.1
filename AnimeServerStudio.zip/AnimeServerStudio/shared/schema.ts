import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Server related schemas
export const serverTypeEnum = pgEnum('server_type', ['web', 'database', 'ai']);
export const serverStatusEnum = pgEnum('server_status', ['active', 'pending', 'stopped', 'processing']);

export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: serverTypeEnum("type").notNull(),
  storage: integer("storage").notNull(),
  ram: integer("ram").notNull(),
  cpu: integer("cpu").notNull(),
  gpu: text("gpu"),
  status: serverStatusEnum("status").notNull().default('pending'),
  createdAt: timestamp("created_at").defaultNow(),
  uptime: integer("uptime").default(0),
  backup: boolean("backup").default(false),
  monitoring: boolean("monitoring").default(false),
  autoScale: boolean("auto_scale").default(false),
  firewall: boolean("firewall").default(false),
  persistentMode: boolean("persistent_mode").default(true),
  apiKey: text("api_key"),
  userId: integer("user_id").notNull(),
});

// Anime episodes schema
export const animeStatusEnum = pgEnum('anime_status', ['completed', 'processing', 'failed']);

export const animeEpisodes = pgTable("anime_episodes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  scenario: text("scenario").notNull(),
  style: text("style").notNull(),
  duration: integer("duration").notNull(),
  characters: text("characters"),
  resolution: text("resolution").notNull(),
  subtitles: boolean("subtitles").default(false),
  voiceover: boolean("voiceover").default(false),
  customMusic: boolean("custom_music").default(false),
  visualEffects: boolean("visual_effects").default(false),
  status: animeStatusEnum("status").notNull().default('processing'),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  size: text("size"),
  filePath: text("file_path"),
  userId: integer("user_id").notNull(),
});

// User schema (required for authentication)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas with zod
export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  createdAt: true 
});

export const insertServerSchema = createInsertSchema(servers).omit({ 
  id: true, 
  createdAt: true, 
  status: true,
  uptime: true
});

export const insertAnimeEpisodeSchema = createInsertSchema(animeEpisodes).omit({ 
  id: true, 
  createdAt: true, 
  completedAt: true, 
  status: true,
  size: true,
  filePath: true
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertServer = z.infer<typeof insertServerSchema>;
export type Server = typeof servers.$inferSelect;

export type InsertAnimeEpisode = z.infer<typeof insertAnimeEpisodeSchema>;
export type AnimeEpisode = typeof animeEpisodes.$inferSelect;
